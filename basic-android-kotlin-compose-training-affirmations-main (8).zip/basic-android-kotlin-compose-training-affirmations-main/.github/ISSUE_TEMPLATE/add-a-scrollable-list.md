---
name: Android Kotlin Fundamentals
about: Describe this issue template's purpose here.
title: 'Add a Scrollable List codelab: '
labels: ''
assignees: ''

---

**Name of the Codelab or Codelab URL**


**Describe the problem**
A clear and concise description of what the problem is.

**In which lesson and step of the codelab can this issue be found?**
Lesson number + step number.

**How to reproduce?**
What are the exact steps to reproduce the problem?

**Versions**
1. What version of Android Studio are you using?
2. What API level are you targeting?

**Additional information**
Add any other context about the problem here.

**codelab:** basic-android-compose-training-add-scrollable-list
